#pragma once

#import "../Common.h"
#import "../Config.h"
#import "../Security/oxorany/oxorany_include.h"
#import "Fallback/Fallback.h"
#import "Foundation/Foundation.h"
#import "GioVoTinh/PatchAPI.h"
#import "UnitySDKiOS/UnitySDKiOS.h"
#import <dispatch/dispatch.h>
#import <os/log.h>

#ifdef __cplusplus
#define LOG_PREFIX NSSENCRYPT("GioVoTinh Mod >>>")
#else
#define LOG_PREFIX @"GioVoTinh Mod >>>"
#endif

static inline os_log_t GetLogger(void) {
    static os_log_t logger;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{
      logger = os_log_create("com.giovotinh.mod", "LienQuanVNMod");
    });

    return logger;
}

#define LOG(...)                                                               \
    do {                                                                       \
        os_log_with_type(GetLogger(), OS_LOG_TYPE_DEFAULT,                     \
                         "%{public}@ %{public}@", LOG_PREFIX,                  \
                         [NSString stringWithFormat:__VA_ARGS__]);             \
    } while (0)

#define timer(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), ^
#define timer_background(sec) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
#define onMain(block) dispatch_async(dispatch_get_main_queue(), block)
