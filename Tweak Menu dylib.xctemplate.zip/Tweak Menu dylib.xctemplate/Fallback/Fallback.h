//
//  Fallback.h
//  LienQuanVNMod
//
//  Created by Le Tien Dat on 7/10/26.
//

#include <cstdint>

namespace Fallback {
uint64_t MethodOffset(uint64_t srcValue, uint64_t fallback);
void *MethodAddress(void *srcValue, void *fallback);
uintptr_t FieldOffset(uintptr_t srcValue, uintptr_t fallback);
} // namespace Fallback
