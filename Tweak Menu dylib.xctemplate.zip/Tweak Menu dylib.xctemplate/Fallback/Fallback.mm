//
//  Fallback.mm
//  LienQuanVNMod
//
//  Created by Le Tien Dat on 7/10/26.
//

#include "Fallback.h"
#import "../GioVoTinh/helper.h"

namespace Fallback {
uint64_t MethodOffset(uint64_t srcValue, uint64_t fallback) {
    return srcValue ? srcValue : fallback;
}

void *MethodAddress(void *srcValue, void *fallback) {
    return (uintptr_t)srcValue ? srcValue : fallback;
}

uintptr_t FieldOffset(uintptr_t srcValue, uintptr_t fallback) {
    if (srcValue)
        return srcValue;

    return fallback;
}
} // namespace Fallback
