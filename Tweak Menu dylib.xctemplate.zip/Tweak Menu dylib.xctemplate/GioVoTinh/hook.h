#import "../Macros.h"
#import "Foundation/Foundation.h"

static bool isJsonLoaded = false;
static int themeID = 0;