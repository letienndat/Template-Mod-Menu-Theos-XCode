//
//  UnitySDKiOS.h
//
//  Made by Đàm Hào
//

#include "UnitySDKiOS.h"
#include "../Utils/RuntimeMacros.h"
#include <algorithm>
#include <dlfcn.h>
#include <fcntl.h>
#include <initializer_list>
#include <mach-o/dyld.h>
#include <mach-o/getsect.h>
#include <mach-o/loader.h>
#include <mutex>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace UnitySDKiOS {

struct ImageDef {
    uint32_t nameIndex;
    int32_t assemblyIndex;
    int32_t typeStart;
    uint32_t typeCount;
    int32_t exportedTypeStart;
    uint32_t exportedTypeCount;
    int32_t entryPointIndex;
    uint32_t token;
    int32_t customAttributeStart;
    uint32_t customAttributeCount;
};

struct TypeDef {
    uint32_t nameIndex;
    uint32_t namespaceIndex;
    int32_t byvalTypeIndex;
    int32_t declaringTypeIndex;
    int32_t parentIndex;
    int32_t elementTypeIndex;
    int32_t genericContainerIndex;
    uint32_t flags;
    int32_t fieldStart;
    int32_t methodStart;
    int32_t eventStart;
    int32_t propertyStart;
    int32_t nestedTypesStart;
    int32_t interfacesStart;
    int32_t vtableStart;
    int32_t interfaceOffsetsStart;
    uint16_t method_count;
    uint16_t property_count;
    uint16_t field_count;
    uint16_t event_count;
    uint16_t nested_type_count;
    uint16_t vtable_count;
    uint16_t interfaces_count;
    uint16_t interface_offsets_count;
    uint32_t bitfield;
    uint32_t token;
};

struct MethodDef {
    uint32_t nameIndex;
    int32_t declaringType;
    int32_t returnType;
    int32_t parameterStart;
    int32_t genericContainerIndex;
    uint32_t token;
    uint16_t flags;
    uint16_t iflags;
    uint16_t slot;
    uint16_t parameterCount;
};

struct ParameterDef {
    uint32_t nameIndex;
    uint32_t token;
    int32_t typeIndex;
};

struct FieldDef {
    uint32_t nameIndex;
    int32_t typeIndex;
    uint32_t token;
};

struct RuntimeIl2CppType {
    const void *data;
    uint32_t bits;
};

struct RuntimeIl2CppArrayType {
    const RuntimeIl2CppType *etype;
    uint8_t rank;
    uint8_t numsizes;
    uint8_t numlobounds;
    uint8_t byref;
};

struct RuntimeIl2CppClassHead {
    void *image;
    void *gc_desc;
    const char *name;
    const char *namespaze;
};

struct CodeRegistration {
    uint64_t reversePInvokeWrapperCount;
    uint64_t reversePInvokeWrappers;
    uint64_t genericMethodPointersCount;
    uint64_t genericMethodPointers;
    uint64_t genericAdjustorThunks;
    uint64_t invokerPointersCount;
    uint64_t invokerPointers;
    uint64_t unresolvedVirtualCallCount;
    uint64_t unresolvedVirtualCallPointers;
    uint64_t interopDataCount;
    uint64_t interopData;
    uint64_t windowsRuntimeFactoryCount;
    uint64_t windowsRuntimeFactoryTable;
    uint64_t codeGenModulesCount;
    uint64_t codeGenModules;
};

struct CodeGenModule {
    uint64_t moduleName;
    int64_t methodPointerCount;
    uint64_t methodPointers;
    int64_t adjustorThunkCount;
    uint64_t adjustorThunks;
    uint64_t invokerIndices;
    uint64_t reversePInvokeWrapperCount;
    uint64_t reversePInvokeWrapperIndices;
    int64_t rgctxRangesCount;
    uint64_t rgctxRanges;
    int64_t rgctxsCount;
    uint64_t rgctxs;
    uint64_t debuggerMetadata;
    uint64_t moduleInitializer;
    uint64_t staticConstructorTypeIndices;
    uint64_t metadataRegistration;
    uint64_t codeRegistration;
};

struct MetadataRegistration {
    int64_t genericClassesCount;
    uint64_t genericClasses;
    int64_t genericInstsCount;
    uint64_t genericInsts;
    int64_t genericMethodTableCount;
    uint64_t genericMethodTable;
    int64_t typesCount;
    uint64_t types;
    int64_t methodSpecsCount;
    uint64_t methodSpecs;
    int64_t fieldOffsetsCount;
    uint64_t fieldOffsets;
    int64_t typeDefinitionsSizesCount;
    uint64_t typeDefinitionsSizes;
    uint64_t metadataUsagesCount;
    uint64_t metadataUsages;
};

struct FileBuffer {
    uint8_t *data = nullptr;
    size_t size = 0;
    bool mapped = false;
};

struct Section {
    uint64_t address = 0;
    uint64_t end = 0;
    bool exec = false;
};

struct Cache {
    FileBuffer meta;
    std::vector<Section>
        execSecs; // __TEXT-segment sections (cstring, const, text)
    std::vector<Section>
        dataSecs; // __DATA*/__DATA_CONST sections (NO __LINKEDIT)
    std::vector<Section>
        stringSecs; // Subset: read-only c-string sections (__cstring)
    // Pre-computed index of every 8-byte aligned value found inside dataSecs
    // whose value falls within the binary's vmaddr range — turns findRefs()
    // from an O(N) full-binary scan into an O(1) hash lookup. Without this the
    // nested findRefs loops in findCodeReg blow up to hours on a 100MB+
    // UnityFramework.
    std::unordered_map<uint64_t, std::vector<uint64_t>> ptrIndex;
    uint64_t binMinVA = 0;
    uint64_t binMaxVA = 0;
    const uint32_t *hdr = nullptr;
    const mach_header_64 *header = nullptr;
    intptr_t slide = 0;
    uint64_t imageBase = 0;
    uint64_t codeReg = 0;
    uint64_t metaReg = 0;
    std::string binaryPath;
    std::string metadataPath;
};

static std::mutex gMutex;
static Cache *gCache = nullptr;
static Status gStatus;

static std::string toStd(NSString *s) {
    return s ? std::string([s UTF8String]) : std::string();
}

static NSString *fromStd(const std::string &s) {
    return [NSString stringWithUTF8String:s.c_str()];
}

static inline os_log_t getLogger(void) {
    static os_log_t logger;
    static dispatch_once_t onceToken;

    dispatch_once(&onceToken, ^{
      logger = os_log_create("com.giovotinh.resolve_unity", "UnitySDKiOS");
    });

    return logger;
}

#define UNITY_LOG_PREFIX @"UnitySDKiOS >>>"
#define UNITY_LOG(...)                                                         \
    do {                                                                       \
        os_log_with_type(getLogger(), OS_LOG_TYPE_DEFAULT,                     \
                         "%{public}@ %{public}@", UNITY_LOG_PREFIX,            \
                         [NSString stringWithFormat:__VA_ARGS__]);             \
    } while (0)

// Tee logger: every diagnostic line goes to both syslog AND a file at
// Documents/UnitySDKiOS.log inside the host process. Under LiveContainer
// this is the WRAPPED GAME's Documents — accessible via LiveContainer's file
// UI without needing USB syslog. Truncates the file on first call per
// process so each launch starts fresh. Public so other il2cpp modules
// (api.mm, il2cpp_runtime.mm) can mirror their diagnostics into the same
// file the user already retrieves.
void unityLog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);

    UNITY_LOG(@"%@", msg);

    static NSString *logPath = nil;
    static std::mutex logMtx;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
      NSArray<NSString *> *dirs = NSSearchPathForDirectoriesInDomains(
          NSDocumentDirectory, NSUserDomainMask, YES);
      if (dirs.count == 0)
          return;
      logPath =
          [dirs.firstObject stringByAppendingPathComponent:@"UnitySDKiOS.log"];
      // Truncate at process start so each launch has a clean log.
      [[NSData data] writeToFile:logPath atomically:NO];
      // Use raw NSLog here — recursing into unityLog from inside this same
      // dispatch_once block would deadlock on the once-token.
      // => Update use os_log_with_type support show log private in iOS >= 26
      UNITY_LOG(@"[UnitySDKiOS] log file: %@", logPath);
    });
    if (!logPath)
        return;

    struct timeval tv;
    gettimeofday(&tv, NULL);
    struct tm tmv;
    localtime_r(&tv.tv_sec, &tmv);
    char ts[32];
    snprintf(ts, sizeof(ts), "%02d:%02d:%02d.%03d", tmv.tm_hour, tmv.tm_min,
             tmv.tm_sec, (int)(tv.tv_usec / 1000));
    NSString *line = [NSString stringWithFormat:@"%s %@\n", ts, msg];
    NSData *data = [line dataUsingEncoding:NSUTF8StringEncoding];

    std::lock_guard<std::mutex> lock(logMtx);
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:logPath];
    if (fh) {
        [fh seekToEndOfFile];
        [fh writeData:data];
        [fh closeFile];
    } else {
        [data writeToFile:logPath atomically:NO];
    }
}

static bool fileExists(NSString *path) {
    return path.length > 0 &&
           [[NSFileManager defaultManager] isReadableFileAtPath:path];
}

static bool readFile(const std::string &path, FileBuffer &out) {
    int fd = open(path.c_str(), O_RDONLY);
    if (fd < 0)
        return false;
    struct stat st{};
    if (fstat(fd, &st) != 0 || st.st_size <= 0) {
        close(fd);
        return false;
    }
    void *data =
        mmap(nullptr, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (data == MAP_FAILED)
        return false;
    out.data = (uint8_t *)data;
    out.size = (size_t)st.st_size;
    out.mapped = true;
    return true;
}

static void freeFile(FileBuffer &b) {
    if (!b.data)
        return;
    if (b.mapped)
        munmap(b.data, b.size);
    else
        free(b.data);
    b = FileBuffer{};
}

static uint32_t xorSubtract(uint32_t value, uint32_t sub, uint32_t key) {
    return ((value - sub) ^ key);
}

static bool deobfMeta(FileBuffer &meta) {
    if (!meta.data || meta.size < 0x100)
        return false;
    uint32_t *header = (uint32_t *)meta.data;
    if (header[0] == 0xFAB11BAF)
        return true;
    if (header[0] != 0xEAB11BAF || header[1] < 29)
        return false;
    if (meta.mapped) {
        uint8_t *copy = (uint8_t *)malloc(meta.size);
        if (!copy)
            return false;
        memcpy(copy, meta.data, meta.size);
        munmap(meta.data, meta.size);
        meta.data = copy;
        meta.mapped = false;
        header = (uint32_t *)meta.data;
    }
    uint32_t input[64];
    uint32_t output[64] = {0};
    memcpy(input, header, sizeof(input));
    output[0] = input[0];
    output[1] = input[1];
    for (int i = 50; i < 64; i++)
        output[i] = input[i];
    output[4] = input[2] ^ 0x00A8C72D;
    output[5] = input[3] ^ 0x00A8C72D;
    output[8] = xorSubtract(input[4], 3, 0x00A8C72E);
    output[9] = xorSubtract(input[5], 7, 0x00A8C72F);
    output[12] = xorSubtract(input[6], 6, 0x00A8C72F);
    output[13] = xorSubtract(input[7], 14, 0x00A8C731);
    output[16] = xorSubtract(input[8], 9, 0x00A8C730);
    output[17] = xorSubtract(input[9], 21, 0x00A8C733);
    output[20] = xorSubtract(input[10], 12, 0x00A8C731);
    output[21] = xorSubtract(input[11], 28, 0x00A8C735);
    output[6] = xorSubtract(input[12], 15, 0x00A8C732);
    output[7] = xorSubtract(input[13], 35, 0x00A8C737);
    output[10] = xorSubtract(input[14], 18, 0x00A8C733);
    output[11] = xorSubtract(input[15], 42, 0x00A8C739);
    output[14] = xorSubtract(input[16], 21, 0x00A8C734);
    output[15] = xorSubtract(input[17], 49, 0x00A8C73B);
    output[18] = xorSubtract(input[18], 24, 0x00A8C735);
    output[19] = xorSubtract(input[19], 56, 0x00A8C73D);
    output[22] = xorSubtract(input[20], 27, 0x00A8C736);
    output[23] = xorSubtract(input[21], 63, 0x00A8C73F);
    output[2] = xorSubtract(input[22], 30, 0x00A8C737);
    output[3] = xorSubtract(input[23], 70, 0x00A8C741);
    output[48] = xorSubtract(input[24], 33, 0x00A8C738);
    output[49] = xorSubtract(input[25], 77, 0x00A8C743);
    output[46] = xorSubtract(input[26], 36, 0x00A8C739);
    output[47] = xorSubtract(input[27], 84, 0x00A8C745);
    output[44] = xorSubtract(input[28], 39, 0x00A8C73A);
    output[45] = xorSubtract(input[29], 91, 0x00A8C747);
    output[42] = xorSubtract(input[30], 42, 0x00A8C73B);
    output[43] = xorSubtract(input[31], 98, 0x00A8C749);
    output[24] = xorSubtract(input[32], 45, 0x00A8C73C);
    output[25] = xorSubtract(input[33], 105, 0x00A8C74B);
    output[28] = xorSubtract(input[34], 48, 0x00A8C73D);
    output[29] = xorSubtract(input[35], 112, 0x00A8C74D);
    output[32] = xorSubtract(input[36], 51, 0x00A8C73E);
    output[33] = xorSubtract(input[37], 119, 0x00A8C74F);
    output[36] = xorSubtract(input[38], 54, 0x00A8C73F);
    output[37] = xorSubtract(input[39], 126, 0x00A8C751);
    output[40] = xorSubtract(input[40], 57, 0x00A8C740);
    output[41] = xorSubtract(input[41], 133, 0x00A8C753);
    output[26] = xorSubtract(input[42], 60, 0x00A8C741);
    output[27] = xorSubtract(input[43], 140, 0x00A8C755);
    output[30] = xorSubtract(input[44], 63, 0x00A8C742);
    output[31] = xorSubtract(input[45], 147, 0x00A8C757);
    output[34] = xorSubtract(input[46], 66, 0x00A8C743);
    output[35] = xorSubtract(input[47], 154, 0x00A8C759);
    output[38] = xorSubtract(input[48], 69, 0x00A8C744);
    output[39] = xorSubtract(input[49], 161, 0x00A8C75B);
    memcpy(header, output, sizeof(output));
    header[0] = 0xFAB11BAF;
    return true;
}

static bool contains(const std::vector<Section> &secs, uint64_t p,
                     uint64_t size = 1) {
    if (!p || size == 0)
        return false;
    for (const auto &s : secs) {
        if (p >= s.address && p <= s.end && size <= s.end - p)
            return true;
    }
    return false;
}

static bool containsAny(const Cache &c, uint64_t p, uint64_t size = 1) {
    return contains(c.dataSecs, p, size) || contains(c.execSecs, p, size);
}

static const char *cstrAt(const Cache &c, uint64_t p) {
    if (!containsAny(c, p, 1))
        return nullptr;
    return (const char *)p;
}

static const char *metadataString(const FileBuffer &meta, const uint32_t *hdr,
                                  uint32_t index) {
    if (!meta.data || !hdr)
        return nullptr;
    uint32_t stringOffset = hdr[6];
    uint32_t stringSize = hdr[7];
    if (index >= stringSize)
        return nullptr;
    uint64_t off = (uint64_t)stringOffset + index;
    if (off >= meta.size)
        return nullptr;
    return (const char *)(meta.data + off);
}

static bool findBytesInSection(const Section &s, const uint8_t *pat,
                               size_t patLen, uint64_t &outAddr) {
    if (!pat || patLen == 0 || s.end <= s.address || s.end - s.address < patLen)
        return false;
    const uint8_t *start = (const uint8_t *)s.address;
    size_t len = (size_t)(s.end - s.address);
    for (size_t i = 0; i + patLen <= len; i++) {
        if (memcmp(start + i, pat, patLen) == 0) {
            outAddr = s.address + i;
            return true;
        }
    }
    return false;
}

// Build c.ptrIndex: for every 8-byte aligned 64-bit value V stored inside a
// data section, if V looks like a pointer into the binary itself (V is in
// [binMinVA, binMaxVA)), record &V in the index. Sub-second on a 100MB
// UnityFramework, replaces what was previously O(N) repeated full scans.
static void buildPointerIndex(Cache &c) {
    c.ptrIndex.clear();
    size_t scanned = 0;
    size_t indexed = 0;
    for (const auto &s : c.dataSecs) {
        for (uint64_t p = s.address; p + sizeof(uint64_t) <= s.end;
             p += sizeof(uint64_t)) {
            scanned++;
            uint64_t v = *(const uint64_t *)p;
            if (v >= c.binMinVA && v < c.binMaxVA) {
                c.ptrIndex[v].push_back(p);
                indexed++;
            }
        }
    }
    unityLog(
        @"[UnitySDKiOS] ptrIndex built: scanned=%zu indexed=%zu unique=%zu",
        scanned, indexed, c.ptrIndex.size());
}

static size_t findRefs(const Cache &c, uint64_t target,
                       std::vector<uint64_t> &refs, size_t maxRefs = 4096) {
    refs.clear();
    if (target < c.binMinVA || target >= c.binMaxVA)
        return 0;
    auto it = c.ptrIndex.find(target);
    if (it == c.ptrIndex.end())
        return 0;
    const auto &list = it->second;
    const size_t take = std::min(list.size(), maxRefs);
    refs.assign(list.begin(), list.begin() + take);
    return refs.size();
}

static int collectImageNames(const FileBuffer &meta, const uint32_t *hdr,
                             const char **outNames, int maxNames) {
    if (!meta.data || !hdr || !outNames || maxNames <= 0)
        return 0;
    uint32_t imagesOffset = hdr[42];
    uint32_t imagesSize = hdr[43];
    if ((uint64_t)imagesOffset + imagesSize > meta.size)
        return 0;
    const ImageDef *images = (const ImageDef *)(meta.data + imagesOffset);
    int imageCount = imagesSize / (int)sizeof(ImageDef);
    int n = 0;
    for (int i = 0; i < imageCount && n < maxNames; i++) {
        const char *name = metadataString(meta, hdr, images[i].nameIndex);
        if (name)
            outNames[n++] = name;
    }
    return n;
}

static bool buildSectionsForPath(const std::string &path, Cache &c) {
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *imagePath = _dyld_get_image_name(i);
        if (!imagePath || path != imagePath)
            continue;
        const mach_header_64 *mh =
            (const mach_header_64 *)_dyld_get_image_header(i);
        if (!mh || mh->magic != MH_MAGIC_64)
            return false;
        intptr_t slide = _dyld_get_image_vmaddr_slide(i);
        c.header = mh;
        c.slide = slide;
        c.imageBase = (uint64_t)slide;

        const uint8_t *lcptr = (const uint8_t *)mh + sizeof(mach_header_64);
        uint64_t minText = UINT64_MAX;
        c.binMinVA = UINT64_MAX;
        c.binMaxVA = 0;

        size_t segCount = 0, sectCount = 0, dataSectCount = 0,
               stringSectCount = 0;

        for (uint32_t n = 0; n < mh->ncmds; n++) {
            const load_command *lc = (const load_command *)lcptr;
            if (lc->cmd == LC_SEGMENT_64) {
                const segment_command_64 *seg = (const segment_command_64 *)lc;
                segCount++;

                const bool isPageZero = strcmp(seg->segname, "__PAGEZERO") == 0;
                const bool isLinkedit = strcmp(seg->segname, "__LINKEDIT") == 0;
                const bool isText = strcmp(seg->segname, "__TEXT") == 0;
                const bool isExec = (seg->initprot & VM_PROT_EXECUTE) != 0;
                const bool isReadable = (seg->initprot & VM_PROT_READ) != 0;

                if (isPageZero || !isReadable || seg->vmsize == 0) {
                    lcptr += lc->cmdsize;
                    continue;
                }

                const uint64_t segAddr =
                    (uint64_t)seg->vmaddr + (uint64_t)slide;
                const uint64_t segEnd = segAddr + seg->vmsize;
                if (segAddr < c.binMinVA)
                    c.binMinVA = segAddr;
                if (segEnd > c.binMaxVA)
                    c.binMaxVA = segEnd;
                if (isText && segAddr < minText)
                    minText = segAddr;

                // Iterate sections within the segment. section_64 entries
                // follow the segment_command_64 header in memory. Decisions are
                // based primarily on SECTION name + segment-level exec flag, so
                // the logic survives split-__TEXT layouts (e.g. __TEXT_EXEC).
                const section_64 *secs =
                    (const section_64 *)((const uint8_t *)seg +
                                         sizeof(segment_command_64));
                for (uint32_t s = 0; s < seg->nsects; s++) {
                    sectCount++;
                    Section sec;
                    sec.address = (uint64_t)secs[s].addr + (uint64_t)slide;
                    sec.end = sec.address + secs[s].size;
                    sec.exec = isExec;
                    if (sec.end <= sec.address)
                        continue;

                    if (isExec) {
                        // Anything in an executable segment counts as part of
                        // the "binary text" range for containsAny() purposes.
                        c.execSecs.push_back(sec);
                    } else if (!isLinkedit) {
                        // __DATA / __DATA_CONST / __DATA_DIRTY / __OBJC etc.
                        // — eligible pointer-storage sections. __LINKEDIT is
                        // excluded: it carries dyld/symbol metadata that has
                        // millions of values not relevant to IL2CPP and
                        // dominates the scan time.
                        c.dataSecs.push_back(sec);
                        dataSectCount++;
                    }

                    // C-string sections — same name regardless of which
                    // (possibly split) __TEXT segment they live in.
                    if (strcmp(secs[s].sectname, "__cstring") == 0 ||
                        strcmp(secs[s].sectname, "__os_log") == 0 ||
                        strcmp(secs[s].sectname, "__objc_methname") == 0 ||
                        strcmp(secs[s].sectname, "__objc_classname") == 0) {
                        c.stringSecs.push_back(sec);
                        stringSectCount++;
                    }
                }

                // Some segments declare 0 sections. Still cover the segment
                // range for containsAny on executable segments — string
                // pointers might fall in there with stripped Mach-O layouts.
                if (seg->nsects == 0 && isExec) {
                    Section sec;
                    sec.address = segAddr;
                    sec.end = segEnd;
                    sec.exec = true;
                    c.execSecs.push_back(sec);
                }
            }
            lcptr += lc->cmdsize;
        }

        if (minText != UINT64_MAX && c.imageBase == 0)
            c.imageBase = minText;
        if (c.binMinVA == UINT64_MAX)
            c.binMinVA = 0;

        unityLog(
            @"[UnitySDKiOS] sections: segs=%zu sects=%zu data=%zu strings=%zu "
            @"text=%zu range=[0x%llx,0x%llx)",
            segCount, sectCount, dataSectCount, stringSectCount,
            c.execSecs.size(), (unsigned long long)c.binMinVA,
            (unsigned long long)c.binMaxVA);

        return !c.execSecs.empty() && !c.dataSecs.empty();
    }
    return false;
}

static bool imageHasIl2CppSymbols(const char *path) {
    if (!path)
        return false;
    void *h = dlopen(path, RTLD_LAZY | RTLD_NOLOAD);
    if (!h)
        return false;
    return dlsym(h, "il2cpp_domain_get") && dlsym(h, "il2cpp_runtime_invoke");
}

std::string FindIL2CPPBinaryPath() {
    std::vector<std::string> loaded;
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *p = _dyld_get_image_name(i);
        if (!p || !*p)
            continue;
        std::string s = p;
        if (s.find("UnityFramework") != std::string::npos ||
            s.find(NAME_BINARY) != std::string::npos)
            loaded.push_back(s);
    }
    for (const auto &p : loaded) {
        if (imageHasIl2CppSymbols(p.c_str()))
            return p;
    }
    NSString *bundle = [[NSBundle mainBundle] bundlePath];
    NSString *exe = [[NSBundle mainBundle] executablePath];
    NSMutableArray<NSString *> *candidates = [NSMutableArray array];
    if (exe)
        [candidates addObject:exe];
    [candidates
        addObject:
            [bundle stringByAppendingPathComponent:
                        @"Frameworks/UnityFramework.framework/UnityFramework"]];
    [candidates
        addObject:[bundle
                      stringByAppendingPathComponent:
                          [NSString stringWithCString:NAME_BINARY
                                             encoding:NSUTF16StringEncoding]]];
    for (NSString *p in candidates) {
        if (fileExists(p)) {
            std::string ps = toStd(p);
            for (const auto &l : loaded)
                if (l == ps)
                    return ps;
        }
    }
    if (!loaded.empty())
        return loaded.front();
    for (NSString *p in candidates)
        if (fileExists(p))
            return toStd(p);
    return std::string();
}

// Try every standard Unity metadata layout under `dir`. Returns the first hit.
static NSString *probeMetadataUnder(NSString *dir) {
    if (dir.length == 0)
        return nil;
    NSArray<NSString *> *relatives = @[
        @"Data/Managed/Metadata/global-metadata.dat",
        @"Frameworks/UnityFramework.framework/Data/Managed/Metadata/global-metadata.dat",
        @"Managed/Metadata/global-metadata.dat",
        @"global-metadata.dat",
    ];
    for (NSString *rel in relatives) {
        NSString *full = [dir stringByAppendingPathComponent:rel];
        if (fileExists(full))
            return full;
    }
    return nil;
}

std::string FindMetadataPath() {
    NSMutableArray<NSString *> *searchRoots = [NSMutableArray array];

    // 1) Derive roots from the actually-loaded UnityFramework binary. This is
    //    the ONLY reliable source under LiveContainer / TrollStore-style hosts
    //    because [NSBundle mainBundle] points at the host (LiveContainer),
    //    not at the wrapped game's .app. dyld, by contrast, has the real path.
    std::string binaryPath = FindIL2CPPBinaryPath();
    if (!binaryPath.empty()) {
        NSString *bp = [NSString stringWithUTF8String:binaryPath.c_str()];
        NSString *dir = [bp
            stringByDeletingLastPathComponent]; // .../UnityFramework.framework
        for (int up = 0; up < 5 && dir.length > 1; up++) {
            [searchRoots addObject:dir];
            dir = [dir stringByDeletingLastPathComponent];
        }
    }

    // 2) Fall back to the host bundle (works for normal install or rootless
    //    tweak injection where mainBundle === wrapped app).
    NSString *hostBundle = [[NSBundle mainBundle] bundlePath];
    if (hostBundle.length)
        [searchRoots addObject:hostBundle];

    // 3) Probe each root.
    for (NSString *root in searchRoots) {
        NSString *hit = probeMetadataUnder(root);
        if (hit) {
            unityLog(@"[UnitySDKiOS] metadata: probed root=%@ → %@", root, hit);
            return toStd(hit);
        }
    }

    // 4) Last-resort recursive search under each root.
    for (NSString *root in searchRoots) {
        NSDirectoryEnumerator *e =
            [[NSFileManager defaultManager] enumeratorAtPath:root];
        NSString *rel = nil;
        while ((rel = [e nextObject])) {
            if ([[rel lastPathComponent]
                    isEqualToString:@"global-metadata.dat"]) {
                NSString *full = [root stringByAppendingPathComponent:rel];
                if (fileExists(full)) {
                    unityLog(
                        @"[UnitySDKiOS] metadata: recursive scan under %@ → %@",
                        root, full);
                    return toStd(full);
                }
            }
        }
    }

    unityLog(@"[UnitySDKiOS] metadata: NOT found. Searched %lu roots.",
             (unsigned long)searchRoots.count);
    return std::string();
}

static bool validMetadataBounds(const FileBuffer &meta, const uint32_t *hdr) {
    if (!meta.data || !hdr || meta.size < 0x100)
        return false;
    if (hdr[0] != 0xFAB11BAF || hdr[1] < 24)
        return false;
    const int pairs[][2] = {{42, 43}, {40, 41}, {12, 13}, {24, 25}, {6, 7}};
    for (auto &p : pairs) {
        if ((uint64_t)hdr[p[0]] + (uint64_t)hdr[p[1]] > meta.size)
            return false;
    }
    return true;
}

static bool findCodeReg(Cache &c, uint64_t &out) {
    const uint8_t feature[] = {'m', 's', 'c', 'o', 'r', 'l', 'i',
                               'b', '.', 'd', 'l', 'l', 0};
    std::vector<uint64_t> refs1, refs2, refs3;
    const int imageCount = c.hdr[43] / (int)sizeof(ImageDef);

    // 1) Locate the "mscorlib.dll" cstring. It lives in __TEXT.__cstring on
    //    iOS Unity builds — scanning every byte of __TEXT (~100MB) was the
    //    main reason the SDK appeared to "hang" on iOS.
    const auto &scanList = c.stringSecs.empty() ? c.execSecs : c.stringSecs;
    size_t cstringHits = 0;
    for (const auto &sec : scanList) {
        uint64_t start = sec.address;
        while (start < sec.end) {
            Section tail = sec;
            tail.address = start;
            uint64_t dll = 0;
            if (!findBytesInSection(tail, feature, sizeof(feature), dll))
                break;
            cstringHits++;
            findRefs(c, dll, refs1);
            for (uint64_t r1 : refs1) {
                findRefs(c, r1, refs2);
                for (uint64_t r2 : refs2) {
                    for (int k = imageCount - 1; k >= 0; k--) {
                        uint64_t needle = r2 - (uint64_t)k * sizeof(uint64_t);
                        findRefs(c, needle, refs3);
                        for (uint64_t r3 : refs3) {
                            uint64_t check = r3 - sizeof(uint64_t);
                            if (!contains(c.dataSecs, check, sizeof(uint64_t)))
                                continue;
                            if (*(const int64_t *)check ==
                                (int64_t)imageCount) {
                                out = r3 - sizeof(uint64_t) * 14;
                                if (contains(c.dataSecs, out,
                                             sizeof(CodeRegistration))) {
                                    unityLog(
                                        @"[UnitySDKiOS] findCodeReg ref-chain "
                                        @"match @0x%llx (mscorlib hits=%zu)",
                                        (unsigned long long)out, cstringHits);
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            start = dll + 1;
        }
    }

    unityLog(@"[UnitySDKiOS] findCodeReg ref-chain found %zu mscorlib cstring "
             @"hits but no match — entering fallback structural scan",
             cstringHits);

    // 2) Structural fallback: walk dataSecs at every 8-byte aligned offset
    //    and treat the bytes there as a candidate Il2CppCodeRegistration. If
    //    its codeGenModules pointer looks valid AND the first few module
    //    names match assembly names from the metadata, accept it.
    const int maxNames = 512;
    const char *names[maxNames];
    int nameCount = collectImageNames(c.meta, c.hdr, names, maxNames);
    unityLog(@"[UnitySDKiOS] fallback: imageNames=%d", nameCount);
    for (const auto &s : c.dataSecs) {
        for (uint64_t p = s.address; p + sizeof(CodeRegistration) <= s.end;
             p += sizeof(uint64_t)) {
            const CodeRegistration *cr = (const CodeRegistration *)p;
            if (cr->codeGenModulesCount <= 0 ||
                cr->codeGenModulesCount > 4096 || !cr->codeGenModules)
                continue;
            if (!containsAny(c, cr->codeGenModules,
                             cr->codeGenModulesCount * sizeof(uint64_t)))
                continue;
            int checkCount =
                (int)std::min<uint64_t>(cr->codeGenModulesCount, 5);
            int matches = 0;
            for (int i = 0; i < checkCount; i++) {
                uint64_t modulePtr =
                    *(const uint64_t *)(cr->codeGenModules +
                                        (uint64_t)i * sizeof(uint64_t));
                if (!containsAny(c, modulePtr, sizeof(CodeGenModule)))
                    continue;
                const CodeGenModule *m = (const CodeGenModule *)modulePtr;
                const char *modName = cstrAt(c, m->moduleName);
                if (!modName || !*modName)
                    continue;
                for (int k = 0; k < nameCount; k++) {
                    if (strcmp(modName, names[k]) == 0) {
                        matches++;
                        break;
                    }
                }
            }
            if (matches > 0) {
                out = p;
                unityLog(@"[UnitySDKiOS] findCodeReg fallback match @0x%llx "
                         @"(matches=%d)",
                         (unsigned long long)out, matches);
                return true;
            }
        }
    }
    return false;
}

static bool findMetaReg(Cache &c, uint64_t &out) {
    int typeCount = c.hdr[41] / (int)sizeof(TypeDef);
    for (const auto &s : c.dataSecs) {
        for (uint64_t p = s.address; p + sizeof(uint64_t) * 4 <= s.end;
             p += sizeof(uint64_t)) {
            int64_t v1 = *(const int64_t *)p;
            int64_t v2 = *(const int64_t *)(p + sizeof(uint64_t) * 2);
            if (v1 != typeCount || v2 != typeCount)
                continue;
            uint64_t ptrs = *(const uint64_t *)(p + sizeof(uint64_t) * 3);
            if (!containsAny(c, ptrs, (uint64_t)typeCount * sizeof(uint64_t)))
                continue;
            bool ok = true;
            for (int i = 0; i < typeCount; i++) {
                uint64_t v =
                    *(const uint64_t *)(ptrs + (uint64_t)i * sizeof(uint64_t));
                if (!containsAny(c, v, 1)) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                uint64_t candidate = p - sizeof(uint64_t) * 10;
                if (contains(c.dataSecs, candidate,
                             sizeof(MetadataRegistration))) {
                    out = candidate;
                    return true;
                }
            }
        }
    }
    return false;
}

static uint8_t getIl2CppTypeEnum(const RuntimeIl2CppType *type) {
    return type ? (uint8_t)((type->bits >> 16) & 0xFFu) : 0;
}

static std::string buildManagedTypeName(const char *namespaze,
                                        const char *name) {
    if (!name || !*name)
        return std::string();
    if (!namespaze || !*namespaze)
        return std::string(name);
    return std::string(namespaze) + "." + name;
}

static std::string primitiveManagedTypeName(uint8_t typeEnum) {
    switch (typeEnum) {
    case 0x01:
        return "System.Void";
    case 0x02:
        return "System.Boolean";
    case 0x03:
        return "System.Char";
    case 0x04:
        return "System.SByte";
    case 0x05:
        return "System.Byte";
    case 0x06:
        return "System.Int16";
    case 0x07:
        return "System.UInt16";
    case 0x08:
        return "System.Int32";
    case 0x09:
        return "System.UInt32";
    case 0x0A:
        return "System.Int64";
    case 0x0B:
        return "System.UInt64";
    case 0x0C:
        return "System.Single";
    case 0x0D:
        return "System.Double";
    case 0x0E:
        return "System.String";
    case 0x18:
        return "System.IntPtr";
    case 0x19:
        return "System.UIntPtr";
    case 0x1C:
        return "System.Object";
    default:
        return std::string();
    }
}

static bool findTypeDefNameByByvalTypeIndex(const Cache &c, int32_t typeIndex,
                                            std::string &outName) {
    uint32_t typesOffset = c.hdr[40], typesSize = c.hdr[41];
    const TypeDef *types = (const TypeDef *)(c.meta.data + typesOffset);
    int typeTotal = typesSize / (int)sizeof(TypeDef);
    for (int i = 0; i < typeTotal; i++) {
        if (types[i].byvalTypeIndex != typeIndex)
            continue;
        const char *ns = metadataString(c.meta, c.hdr, types[i].namespaceIndex);
        const char *name = metadataString(c.meta, c.hdr, types[i].nameIndex);
        outName = buildManagedTypeName(ns, name);
        return !outName.empty();
    }
    return false;
}

static std::string formatManagedArraySuffix(uint8_t rank) {
    if (rank <= 1)
        return "[]";
    return "[" + std::string((size_t)(rank - 1), ',') + "]";
}

static std::string resolveRuntimeTypeName(const Cache &c,
                                          const RuntimeIl2CppType *type,
                                          int32_t typeIndex);

static std::string resolveTypeNameByIndex(const Cache &c, int32_t typeIndex) {
    if (typeIndex < 0)
        return std::string();
    const MetadataRegistration *mr = (const MetadataRegistration *)c.metaReg;
    if (!mr || typeIndex >= mr->typesCount)
        return std::string();
    if (!containsAny(c, mr->types, (uint64_t)mr->typesCount * sizeof(uint64_t)))
        return std::string();
    uint64_t typePtr =
        *(const uint64_t *)(mr->types + (uint64_t)typeIndex * sizeof(uint64_t));
    if (!typePtr)
        return std::string();
    return resolveRuntimeTypeName(c, (const RuntimeIl2CppType *)typePtr,
                                  typeIndex);
}

static std::string resolveRuntimeTypeName(const Cache &c,
                                          const RuntimeIl2CppType *type,
                                          int32_t typeIndex) {
    if (!type)
        return std::string();

    const uint8_t typeEnum = getIl2CppTypeEnum(type);
    std::string primitive = primitiveManagedTypeName(typeEnum);
    if (!primitive.empty())
        return primitive;

    switch (typeEnum) {
    case 0x0F: {
        const std::string inner = resolveRuntimeTypeName(
            c, (const RuntimeIl2CppType *)type->data, -1);
        return inner.empty() ? std::string() : inner + "*";
    }
    case 0x10: {
        const std::string inner = resolveRuntimeTypeName(
            c, (const RuntimeIl2CppType *)type->data, -1);
        return inner.empty() ? std::string() : inner + "&";
    }
    case 0x11:
    case 0x12: {
        std::string typeName;
        if (findTypeDefNameByByvalTypeIndex(c, typeIndex, typeName))
            return typeName;

        const RuntimeIl2CppClassHead *klass =
            (const RuntimeIl2CppClassHead *)type->data;
        if (!klass)
            return std::string();
        return buildManagedTypeName(klass->namespaze, klass->name);
    }
    case 0x14: {
        const RuntimeIl2CppArrayType *arrayType =
            (const RuntimeIl2CppArrayType *)type->data;
        if (!arrayType || !arrayType->etype)
            return std::string();
        const std::string inner =
            resolveRuntimeTypeName(c, arrayType->etype, -1);
        return inner.empty()
                   ? std::string()
                   : inner + formatManagedArraySuffix(arrayType->rank);
    }
    case 0x1D: {
        const std::string inner = resolveRuntimeTypeName(
            c, (const RuntimeIl2CppType *)type->data, -1);
        return inner.empty() ? std::string() : inner + "[]";
    }
    default:
        return std::string();
    }
}

static bool methodMatchesSignature(const Cache &c, const MethodDef &method,
                                   const std::vector<std::string> &paramTypes) {
    if ((size_t)method.parameterCount != paramTypes.size())
        return false;

    uint32_t parametersOffset = c.hdr[22], parametersSize = c.hdr[23];
    const ParameterDef *parameters =
        (const ParameterDef *)(c.meta.data + parametersOffset);
    int parameterTotal = parametersSize / (int)sizeof(ParameterDef);

    for (size_t i = 0; i < paramTypes.size(); i++) {
        const int32_t paramIndex = method.parameterStart + (int32_t)i;
        if (paramIndex < 0 || paramIndex >= parameterTotal)
            return false;
        const std::string actualType =
            resolveTypeNameByIndex(c, parameters[paramIndex].typeIndex);
        if (actualType.empty() || actualType != paramTypes[i])
            return false;
    }

    return true;
}

static bool findMethodToken(const Cache &c, const char *imageName,
                            const char *typeNs, const char *typeName,
                            const char *methodName, int args, uint32_t &token) {
    uint32_t imagesOffset = c.hdr[42], imagesSize = c.hdr[43];
    uint32_t typesOffset = c.hdr[40], typesSize = c.hdr[41];
    uint32_t methodsOffset = c.hdr[12], methodsSize = c.hdr[13];
    const ImageDef *images = (const ImageDef *)(c.meta.data + imagesOffset);
    const TypeDef *types = (const TypeDef *)(c.meta.data + typesOffset);
    const MethodDef *methods = (const MethodDef *)(c.meta.data + methodsOffset);
    int imageCount = imagesSize / (int)sizeof(ImageDef);
    int typeTotal = typesSize / (int)sizeof(TypeDef);
    int methodTotal = methodsSize / (int)sizeof(MethodDef);
    for (int i = 0; i < imageCount; i++) {
        const char *img = metadataString(c.meta, c.hdr, images[i].nameIndex);
        if (!img || strcmp(img, imageName) != 0)
            continue;
        int end =
            std::min<int>(images[i].typeStart + images[i].typeCount, typeTotal);
        for (int t = images[i].typeStart; t >= 0 && t < end; t++) {
            const char *ns =
                metadataString(c.meta, c.hdr, types[t].namespaceIndex);
            const char *tn = metadataString(c.meta, c.hdr, types[t].nameIndex);
            if (!tn || strcmp(tn, typeName) != 0)
                continue;
            if (typeNs && (!ns || strcmp(ns, typeNs) != 0))
                continue;
            int mend = std::min<int>(
                types[t].methodStart + types[t].method_count, methodTotal);
            for (int m = types[t].methodStart; m >= 0 && m < mend; m++) {
                const char *mn =
                    metadataString(c.meta, c.hdr, methods[m].nameIndex);
                if (!mn || strcmp(mn, methodName) != 0)
                    continue;
                if (args >= 0 && methods[m].parameterCount != args)
                    continue;
                token = methods[m].token;
                return true;
            }
        }
    }
    return false;
}

static bool findMethodTokenBySignature(
    const Cache &c, const char *imageName, const char *typeNs,
    const char *typeName, const char *methodName,
    std::initializer_list<const char *> paramTypeNames, uint32_t &token) {
    uint32_t imagesOffset = c.hdr[42], imagesSize = c.hdr[43];
    uint32_t typesOffset = c.hdr[40], typesSize = c.hdr[41];
    uint32_t methodsOffset = c.hdr[12], methodsSize = c.hdr[13];
    const ImageDef *images = (const ImageDef *)(c.meta.data + imagesOffset);
    const TypeDef *types = (const TypeDef *)(c.meta.data + typesOffset);
    const MethodDef *methods = (const MethodDef *)(c.meta.data + methodsOffset);
    const int imageCount = imagesSize / (int)sizeof(ImageDef);
    const int typeTotal = typesSize / (int)sizeof(TypeDef);
    const int methodTotal = methodsSize / (int)sizeof(MethodDef);
    std::vector<std::string> requestedParamTypes;
    requestedParamTypes.reserve(paramTypeNames.size());
    for (const char *paramTypeName : paramTypeNames) {
        requestedParamTypes.emplace_back(paramTypeName ? paramTypeName : "");
    }

    for (int i = 0; i < imageCount; i++) {
        const char *img = metadataString(c.meta, c.hdr, images[i].nameIndex);
        if (!img || strcmp(img, imageName) != 0)
            continue;
        int end =
            std::min<int>(images[i].typeStart + images[i].typeCount, typeTotal);
        for (int t = images[i].typeStart; t >= 0 && t < end; t++) {
            const char *ns =
                metadataString(c.meta, c.hdr, types[t].namespaceIndex);
            const char *tn = metadataString(c.meta, c.hdr, types[t].nameIndex);
            if (!tn || strcmp(tn, typeName) != 0)
                continue;
            if (typeNs && (!ns || strcmp(ns, typeNs) != 0))
                continue;
            int mend = std::min<int>(
                types[t].methodStart + types[t].method_count, methodTotal);
            for (int m = types[t].methodStart; m >= 0 && m < mend; m++) {
                const char *mn =
                    metadataString(c.meta, c.hdr, methods[m].nameIndex);
                if (!mn || strcmp(mn, methodName) != 0)
                    continue;
                if (!methodMatchesSignature(c, methods[m], requestedParamTypes))
                    continue;
                token = methods[m].token;
                return true;
            }
        }
    }

    return false;
}

static uint64_t findMethodOffsetFromToken(const Cache &c, const char *imageName,
                                          uint32_t token) {
    uint64_t methodIndex = token & 0x00FFFFFFu;
    if (methodIndex == 0)
        return 0;
    const CodeRegistration *cr = (const CodeRegistration *)c.codeReg;
    if (!containsAny(c, cr->codeGenModules,
                     cr->codeGenModulesCount * sizeof(uint64_t)))
        return 0;
    for (uint64_t i = 0; i < cr->codeGenModulesCount; i++) {
        uint64_t modulePtr =
            *(const uint64_t *)(cr->codeGenModules + i * sizeof(uint64_t));
        if (!containsAny(c, modulePtr, sizeof(CodeGenModule)))
            continue;
        const CodeGenModule *m = (const CodeGenModule *)modulePtr;
        const char *modName = cstrAt(c, m->moduleName);
        if (!modName || strcmp(modName, imageName) != 0)
            continue;
        if (methodIndex > (uint64_t)m->methodPointerCount)
            return 0;
        if (!containsAny(c, m->methodPointers,
                         (uint64_t)m->methodPointerCount * sizeof(uint64_t)))
            return 0;
        uint64_t va = *(const uint64_t *)(m->methodPointers +
                                          (methodIndex - 1) * sizeof(uint64_t));
        return va > c.imageBase ? va - c.imageBase : va;
    }
    return 0;
}

static bool findFieldIndex(const Cache &c, const char *imageName,
                           const char *typeNs, const char *typeName,
                           const char *fieldName, int &typeIndex,
                           int &fieldIndex, bool &valueType) {
    uint32_t imagesOffset = c.hdr[42], imagesSize = c.hdr[43];
    uint32_t typesOffset = c.hdr[40], typesSize = c.hdr[41];
    uint32_t fieldsOffset = c.hdr[24], fieldsSize = c.hdr[25];
    const ImageDef *images = (const ImageDef *)(c.meta.data + imagesOffset);
    const TypeDef *types = (const TypeDef *)(c.meta.data + typesOffset);
    const FieldDef *fields = (const FieldDef *)(c.meta.data + fieldsOffset);
    int imageCount = imagesSize / (int)sizeof(ImageDef);
    int typeTotal = typesSize / (int)sizeof(TypeDef);
    int fieldTotal = fieldsSize / (int)sizeof(FieldDef);
    for (int i = 0; i < imageCount; i++) {
        const char *img = metadataString(c.meta, c.hdr, images[i].nameIndex);
        if (!img || strcmp(img, imageName) != 0)
            continue;
        int end =
            std::min<int>(images[i].typeStart + images[i].typeCount, typeTotal);
        for (int t = images[i].typeStart; t >= 0 && t < end; t++) {
            const char *ns =
                metadataString(c.meta, c.hdr, types[t].namespaceIndex);
            const char *tn = metadataString(c.meta, c.hdr, types[t].nameIndex);
            if (!tn || strcmp(tn, typeName) != 0)
                continue;
            if (typeNs && (!ns || strcmp(ns, typeNs) != 0))
                continue;
            int fend = std::min<int>(types[t].fieldStart + types[t].field_count,
                                     fieldTotal);
            for (int f = types[t].fieldStart; f >= 0 && f < fend; f++) {
                const char *fn =
                    metadataString(c.meta, c.hdr, fields[f].nameIndex);
                if (!fn || strcmp(fn, fieldName) != 0)
                    continue;
                typeIndex = t;
                fieldIndex = f - types[t].fieldStart;
                valueType = (types[t].bitfield & 0x1) != 0;
                return true;
            }
        }
    }
    return false;
}

static bool initCache(Cache &c) {
    unityLog(@"[UnitySDKiOS] === EnsureCache start ===");

    c.binaryPath = FindIL2CPPBinaryPath();
    unityLog(@"[UnitySDKiOS] step 1/8 binary: %s",
             c.binaryPath.empty() ? "(empty)" : c.binaryPath.c_str());
    if (c.binaryPath.empty()) {
        gStatus.detail = "Cannot find loaded UnityFramework/app binary";
        return false;
    }

    c.metadataPath = FindMetadataPath();
    unityLog(@"[UnitySDKiOS] step 2/8 metadata: %s",
             c.metadataPath.empty() ? "(empty)" : c.metadataPath.c_str());
    if (c.metadataPath.empty()) {
        gStatus.detail = "Cannot find global-metadata.dat (LiveContainer? "
                         "Re-check bundle paths)";
        return false;
    }

    unityLog(@"[UnitySDKiOS] step 3/8 parsing Mach-O sections…");
    if (!buildSectionsForPath(c.binaryPath, c)) {
        gStatus.detail = "Cannot parse Mach-O sections for " + c.binaryPath;
        return false;
    }

    unityLog(@"[UnitySDKiOS] step 4/8 reading metadata file…");
    if (!readFile(c.metadataPath, c.meta)) {
        gStatus.detail = "Cannot read metadata: " + c.metadataPath;
        return false;
    }
    unityLog(@"[UnitySDKiOS] step 4/8 metadata size=%zu", c.meta.size);

    unityLog(@"[UnitySDKiOS] step 5/8 deobfuscating metadata…");
    if (!deobfMeta(c.meta)) {
        gStatus.detail = "Unsupported metadata magic or deobfuscation failed";
        return false;
    }
    c.hdr = (const uint32_t *)c.meta.data;
    unityLog(@"[UnitySDKiOS] step 5/8 header magic=0x%08x version=%u", c.hdr[0],
             c.hdr[1]);

    if (!validMetadataBounds(c.meta, c.hdr)) {
        gStatus.detail = "Invalid metadata header/bounds";
        return false;
    }
    const int imageCount = c.hdr[43] / (int)sizeof(ImageDef);
    const int typeCount = c.hdr[41] / (int)sizeof(TypeDef);
    unityLog(@"[UnitySDKiOS] step 5/8 imageCount=%d typeCount=%d", imageCount,
             typeCount);

    unityLog(@"[UnitySDKiOS] step 6/8 building pointer index…");
    buildPointerIndex(c);

    unityLog(@"[UnitySDKiOS] step 7/8 locating Il2CppCodeRegistration…");
    if (!findCodeReg(c, c.codeReg)) {
        gStatus.detail = "Cannot locate Il2CppCodeRegistration";
        return false;
    }
    unityLog(@"[UnitySDKiOS] step 7/8 codeReg=0x%llx",
             (unsigned long long)c.codeReg);

    unityLog(@"[UnitySDKiOS] step 8/8 locating Il2CppMetadataRegistration…");
    if (!findMetaReg(c, c.metaReg)) {
        gStatus.detail = "Cannot locate Il2CppMetadataRegistration";
        return false;
    }
    unityLog(@"[UnitySDKiOS] step 8/8 metaReg=0x%llx",
             (unsigned long long)c.metaReg);

    gStatus.initialized = true;
    gStatus.binaryPath = c.binaryPath;
    gStatus.metadataPath = c.metadataPath;
    gStatus.imageBase = c.imageBase;
    gStatus.codeRegistration = c.codeReg;
    gStatus.metadataRegistration = c.metaReg;
    gStatus.detail = "OK";
    unityLog(@"[UnitySDKiOS] === EnsureCache OK (imageBase=0x%llx) ===",
             (unsigned long long)c.imageBase);
    return true;
}

bool EnsureCache() {
    std::lock_guard<std::mutex> lock(gMutex);
    if (gCache)
        return true;
    Cache *c = new Cache();
    if (!initCache(*c)) {
        gStatus.binaryPath = c->binaryPath;
        gStatus.metadataPath = c->metadataPath;
        unityLog(@"[UnitySDKiOS] === EnsureCache FAILED: %s ===",
                 gStatus.detail.c_str());
        freeFile(c->meta);
        delete c;
        return false;
    }
    gCache = c;
    return true;
}

const Status &GetStatus() { return gStatus; }

uint64_t FindMethodOffset(const char *imageName, const char *typeNamespace,
                          const char *typeName, const char *methodName,
                          int argsCount) {
    if (!EnsureCache())
        return 0;
    uint32_t token = 0;
    if (!findMethodToken(*gCache, imageName, typeNamespace, typeName,
                         methodName, argsCount, token))
        return 0;
    return findMethodOffsetFromToken(*gCache, imageName, token);
}

uint64_t
FindMethodOffsetBySignature(const char *imageName, const char *typeNamespace,
                            const char *typeName, const char *methodName,
                            std::initializer_list<const char *> paramTypes) {
    if (!EnsureCache())
        return 0;
    uint32_t token = 0;
    if (!findMethodTokenBySignature(*gCache, imageName, typeNamespace, typeName,
                                    methodName, paramTypes, token))
        return 0;
    return findMethodOffsetFromToken(*gCache, imageName, token);
}

void *GetMethodAddress(uintptr_t imageBase, const char *imageName,
                       const char *typeNamespace, const char *typeName,
                       const char *methodName, int argsCount) {
    uint64_t rva = FindMethodOffset(imageName, typeNamespace, typeName,
                                    methodName, argsCount);
    if (!rva)
        return nullptr;
    return (void *)(imageBase + (uintptr_t)rva);
}

int FindFieldOffset(const char *imageName, const char *typeNamespace,
                    const char *typeName, const char *fieldName) {
    if (!EnsureCache())
        return 0;
    int typeIndex = -1, fieldIndex = -1;
    bool valueType = false;
    if (!findFieldIndex(*gCache, imageName, typeNamespace, typeName, fieldName,
                        typeIndex, fieldIndex, valueType))
        return 0;
    const MetadataRegistration *mr =
        (const MetadataRegistration *)gCache->metaReg;
    if (typeIndex < 0 || typeIndex >= mr->fieldOffsetsCount)
        return 0;
    if (!containsAny(*gCache, mr->fieldOffsets,
                     (uint64_t)mr->fieldOffsetsCount * sizeof(uint64_t)))
        return 0;
    uint64_t perType =
        *(const uint64_t *)(mr->fieldOffsets +
                            (uint64_t)typeIndex * sizeof(uint64_t));
    if (!containsAny(*gCache, perType,
                     (uint64_t)(fieldIndex + 1) * sizeof(int32_t)))
        return 0;
    int32_t off =
        *(const int32_t *)(perType + (uint64_t)fieldIndex * sizeof(int32_t));
    if (off > 0 && valueType)
        off -= 16;
    return off;
}

uintptr_t GetFieldOffset(const char *imageName, const char *typeNamespace,
                         const char *typeName, const char *fieldName) {
    return (uintptr_t)FindFieldOffset(imageName, typeNamespace, typeName,
                                      fieldName);
}

bool GetMetadataView(MetadataView &out) {
    if (!EnsureCache())
        return false;
    if (!gCache || !gCache->meta.data || !gCache->hdr)
        return false;
    const uint32_t *h = gCache->hdr;
    out.metaBase = gCache->meta.data;
    out.metaSize = gCache->meta.size;
    out.hdr = h;
    out.imageBase = gCache->imageBase;
    out.codeReg = gCache->codeReg;
    out.metaReg = gCache->metaReg;
    // Metadata header layout for version 29 (Unity 2022.3.x):
    //   hdr[ 6/ 7] = strings
    //   hdr[12/13] = methods
    //   hdr[22/23] = parameters
    //   hdr[24/25] = fields
    //   hdr[40/41] = types
    //   hdr[42/43] = images
    //   hdr[44/45] = assemblies
    out.stringsOffset = h[6];
    out.stringsSize = h[7];
    out.propertiesOffset = h[10];
    out.propertiesSize = h[11];
    out.methodsOffset = h[12];
    out.methodsSize = h[13];
    out.parametersOffset = h[22];
    out.parametersSize = h[23];
    out.fieldsOffset = h[24];
    out.fieldsSize = h[25];
    out.typesOffset = h[40];
    out.typesSize = h[41];
    out.imagesOffset = h[42];
    out.imagesSize = h[43];
    out.assembliesOffset = h[44];
    out.assembliesSize = h[45];
    return true;
}

} // namespace UnitySDKiOS
