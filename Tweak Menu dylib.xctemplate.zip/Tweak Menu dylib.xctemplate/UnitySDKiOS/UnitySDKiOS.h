//
//  UnitySDKiOS.h
//
//  Made by Đàm Hào
//

#pragma once

#include <Foundation/Foundation.h>
#include <initializer_list>
#include <stdint.h>
#include <string>

namespace UnitySDKiOS {
struct Status {
    bool initialized = false;
    std::string binaryPath;
    std::string metadataPath;
    std::string detail;
    uint64_t imageBase = 0;
    uint64_t codeRegistration = 0;
    uint64_t metadataRegistration = 0;
};

std::string FindIL2CPPBinaryPath();
std::string FindMetadataPath();
bool EnsureCache();
const Status &GetStatus();

// Tee logger: every line goes to syslog (NSLog) AND is appended to
// Documents/UnitySDKiOS.log inside the host process (= the wrapped game
// when running under LiveContainer). Truncated once per process launch.
void unityLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);

// Read-only view of the parsed metadata that il2cpp_metaonly.mm uses to
// synthesize il2cpp_* runtime functions when the loaded UnityFramework
// has its symbols stripped/renamed (Beebyte / IL2CPP Symbol Hider).
// All pointers below address either the metadata file buffer (read-only,
// owned by UnitySDKiOS) or live runtime structures inside the host
// binary (already loaded by dyld) — no allocation, no copies.
struct MetadataView {
    const uint8_t *metaBase; // start of global-metadata.dat buffer
    size_t metaSize;
    const uint32_t *hdr; // metaBase as uint32_t* (header layout)
    uint64_t imageBase;  // host-binary slide-adjusted base VA
    uint64_t codeReg;    // address of live Il2CppCodeRegistration
    uint64_t metaReg;    // address of live Il2CppMetadataRegistration
    // Predigested table offsets (hdr[42]/hdr[43] etc.) for convenience.
    uint32_t imagesOffset, imagesSize;
    uint32_t typesOffset, typesSize;
    uint32_t methodsOffset, methodsSize;
    uint32_t fieldsOffset, fieldsSize;
    uint32_t parametersOffset, parametersSize;
    uint32_t propertiesOffset, propertiesSize;
    uint32_t assembliesOffset, assembliesSize;
    uint32_t stringsOffset, stringsSize;
};
// Returns false if EnsureCache() hasn't run or failed. The returned view
// points into the long-lived metadata buffer; it is valid for the
// remainder of the process lifetime.
bool GetMetadataView(MetadataView &out);

uint64_t FindMethodOffset(const char *imageName, const char *typeNamespace,
                          const char *typeName, const char *methodName,
                          int argsCount);

uint64_t
FindMethodOffsetBySignature(const char *imageName, const char *typeNamespace,
                            const char *typeName, const char *methodName,
                            std::initializer_list<const char *> paramTypes);

void *GetMethodAddress(uintptr_t imageBase, const char *imageName,
                       const char *typeNamespace, const char *typeName,
                       const char *methodName, int argsCount);

int FindFieldOffset(const char *imageName, const char *typeNamespace,
                    const char *typeName, const char *fieldName);

uintptr_t GetFieldOffset(const char *imageName, const char *typeNamespace,
                         const char *typeName, const char *fieldName);
} // namespace UnitySDKiOS
